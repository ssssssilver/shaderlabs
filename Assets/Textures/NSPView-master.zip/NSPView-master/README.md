# NSPView
查看、安装NSP等（FTP、USB、NUT）功能

详细介绍链接：https://www.91wii.com/thread-119564-1-1.html
